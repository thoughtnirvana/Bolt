require "lib/helpers"

# Copy a copy of this site to the out directory
puts "Creating out/bolt-web.tar"
`tar -cvvf ./out/bolt-web.tar .`

page "index" do
  render "home"
end

page "tutorial" do 
  render "tutorial"
end