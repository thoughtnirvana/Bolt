def is_active(path, current_path)
  "active" if path == "/#{current_path}"
end