def is_active(path, current_path)
  "active" if path == current_path
end

def proper_u(path)
  if !path[0..3].nil? and path[0..3] == "http"
    return path
  else
    return u(path)
  end
end